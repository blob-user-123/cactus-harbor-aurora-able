#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  osascript -e 'display alert "Latch needs Node.js" message "A browser window will open so you can install it for free. Then double-click Start Latch again."' >/dev/null 2>&1 || true
  open "https://nodejs.org/en/download"
  exit 1
fi
exec node server.mjs
