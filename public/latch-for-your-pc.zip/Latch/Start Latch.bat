@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo Latch needs Node.js, which is free.
  echo A browser window will open to the download page.
  echo Install it, then double-click Start Latch again.
  echo.
  start "" "https://nodejs.org/en/download"
  pause
  exit /b 1
)
node server.mjs
echo.
echo Latch stopped.
pause
