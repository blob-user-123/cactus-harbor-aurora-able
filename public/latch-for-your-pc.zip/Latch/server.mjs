import { createServer } from "node:http";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const root = dirname(fileURLToPath(import.meta.url));
const indexHtml = readFileSync(join(root, "index.html"));
const favicon = readFileSync(join(root, "favicon.svg"));
const SHOP_ORIGIN = "https://www.cerberusknives.com";
const DEFAULT_URLS = [`${SHOP_ORIGIN}/folding-knives`];

function normalizeShopUrl(input) {
  let url;
  try {
    url = new URL(String(input).trim());
  } catch {
    return null;
  }
  const host = url.hostname.toLowerCase();
  if (url.protocol !== "https:") return null;
  if (host !== "cerberusknives.com" && host !== "www.cerberusknives.com") return null;
  if (url.username || url.password) return null;
  const parts = url.pathname.split("/").filter(Boolean);
  if (parts.length < 1 || parts.length > 3) return null;
  if (parts.some((part) => !/^[a-z0-9-]+$/i.test(part))) return null;
  const blocked = new Set(["api", "checkout", "commerce", "cart", "account"]);
  if (blocked.has(parts[0].toLowerCase())) return null;
  return `${SHOP_ORIGIN}/${parts.join("/")}`;
}

function cents(value) {
  const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(n) ? Math.round(n) : 0;
}

function safePath(fullUrl, fallback) {
  if (typeof fullUrl !== "string") return fallback;
  if (!fullUrl.startsWith("/") || fullUrl.startsWith("//") || fullUrl.includes("\\")) return fallback;
  const path = fullUrl.split("?")[0];
  if (!/^\/[a-z0-9/-]+$/i.test(path)) return fallback;
  return path;
}

function safeImage(value) {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:") return null;
    const host = url.hostname;
    const ok =
      host.endsWith("squarespace-cdn.com") ||
      host.endsWith("squarespace.com") ||
      host.endsWith("cerberusknives.com");
    if (!ok) return null;
    if (!/\.(jpe?g|png|webp|gif|avif)(\?|$)/i.test(url.pathname)) return null;
    return url.toString();
  } catch {
    return null;
  }
}

function firstImage(item) {
  const direct = safeImage(item.assetUrl);
  if (direct) return direct;
  for (const pool of [item.variants, item.items]) {
    if (!Array.isArray(pool)) continue;
    for (const entry of pool) {
      if (!entry || typeof entry !== "object") continue;
      const main = entry.mainImage;
      const fromMain = main && typeof main === "object" ? safeImage(main.assetUrl) : null;
      if (fromMain) return fromMain;
      const fromSelf = safeImage(entry.assetUrl);
      if (fromSelf) return fromSelf;
    }
  }
  return null;
}

function variantLabel(raw, sku) {
  const attributes = raw.attributes;
  if (attributes && typeof attributes === "object") {
    const values = Object.values(attributes).filter((value) => typeof value === "string" && value.length > 0);
    if (values.length) return values.join(" · ");
  }
  if (Array.isArray(raw.optionValues)) {
    const values = raw.optionValues
      .map((option) => (option && typeof option === "object" && typeof option.value === "string" ? option.value : ""))
      .filter(Boolean);
    if (values.length) return values.join(" · ");
  }
  return sku;
}

function parseVariant(raw) {
  if (!raw || typeof raw !== "object") return null;
  if (typeof raw.sku !== "string" || !/^[A-Za-z0-9_-]{1,40}$/.test(raw.sku)) return null;
  const qty = Math.max(0, cents(raw.qtyInStock));
  const unlimited = raw.unlimited === true;
  return {
    sku: raw.sku,
    label: variantLabel(raw, raw.sku),
    priceCents: cents(raw.price),
    qty,
    unlimited,
    inStock: unlimited || qty > 0,
  };
}

function parseItem(raw, requestedPath) {
  if (!raw || typeof raw !== "object") return null;
  if (typeof raw.id !== "string" || !raw.id) return null;
  const variants = (Array.isArray(raw.variants) ? raw.variants : []).map(parseVariant).filter(Boolean);
  if (!variants.length) return null;
  const path = safePath(raw.fullUrl, requestedPath);
  return {
    id: raw.id,
    title: typeof raw.title === "string" && raw.title.trim() ? raw.title.trim() : "Untitled",
    path,
    href: `${SHOP_ORIGIN}${path}`,
    image: firstImage(raw),
    variants,
  };
}

function parseCatalogPayload(data, requestedPath) {
  if (!data || typeof data !== "object") return [];
  const rawItems = [];
  if (data.item && typeof data.item === "object") rawItems.push(data.item);
  if (Array.isArray(data.items)) rawItems.push(...data.items);
  const listings = [];
  const seen = new Set();
  for (const raw of rawItems) {
    const listing = parseItem(raw, requestedPath);
    if (!listing || seen.has(listing.id)) continue;
    seen.add(listing.id);
    listings.push(listing);
  }
  return listings;
}

async function loadUrl(url) {
  const target = new URL(url);
  target.searchParams.set("format", "json");
  target.searchParams.set("_", String(Date.now()));
  const response = await fetch(target, {
    redirect: "manual",
    cache: "no-store",
    signal: AbortSignal.timeout(7000),
    headers: {
      accept: "application/json",
      "cache-control": "no-cache",
      pragma: "no-cache",
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    },
  });
  if (response.status >= 300 && response.status < 400) {
    throw new Error("Refused a redirect off the shop.");
  }
  if (!response.ok) throw new Error(`Shop returned HTTP ${response.status}`);
  const text = await response.text();
  if (text.length > 2_000_000) throw new Error("Shop response was too large.");
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error("Shop didn't return product data.");
  }
  return parseCatalogPayload(json, target.pathname);
}

async function catalog(urls) {
  const started = Date.now();
  const clean = [];
  for (const value of urls.slice(0, 6)) {
    const normalized = normalizeShopUrl(value);
    if (normalized && !clean.includes(normalized)) clean.push(normalized);
  }
  const list = clean.length ? clean : [...DEFAULT_URLS];
  const batches = await Promise.all(
    list.map(async (url) => {
      try {
        return { url, listings: await loadUrl(url), error: null };
      } catch (error) {
        const message = error instanceof Error ? error.message : "Couldn't reach the shop.";
        return { url, listings: [], error: message.slice(0, 180) };
      }
    }),
  );
  const listings = [];
  const seen = new Set();
  const errors = [];
  for (const batch of batches) {
    if (batch.error) errors.push({ url: batch.url, message: batch.error });
    for (const listing of batch.listings) {
      if (seen.has(listing.id)) continue;
      seen.add(listing.id);
      listings.push(listing);
    }
  }
  return { listings, errors, checkedAt: Date.now(), tookMs: Date.now() - started };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > 16_000) {
        reject(new Error("Too large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function send(res, status, body, type) {
  res.writeHead(status, {
    "content-type": type,
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
  });
  res.end(body);
}

function openBrowser(url) {
  try {
    let child;
    if (process.platform === "win32") {
      child = spawn("cmd", ["/c", "start", "", url], { detached: true, stdio: "ignore" });
    } else if (process.platform === "darwin") {
      child = spawn("open", [url], { detached: true, stdio: "ignore" });
    } else {
      child = spawn("xdg-open", [url], { detached: true, stdio: "ignore" });
    }
    child.on("error", () => {});
    child.unref();
  } catch {
    /* the printed address is the fallback */
  }
}

function listen(port) {
  const server = createServer(async (req, res) => {
    const path = (req.url || "/").split("?")[0];
    try {
      if (req.method === "GET" && (path === "/" || path === "/index.html")) {
        send(res, 200, indexHtml, "text/html; charset=utf-8");
        return;
      }
      if (req.method === "GET" && path === "/favicon.svg") {
        send(res, 200, favicon, "image/svg+xml");
        return;
      }
      if (req.method === "POST" && path === "/api/catalog") {
        const raw = await readBody(req);
        let urls = [];
        try {
          const parsed = JSON.parse(raw || "{}");
          if (parsed && Array.isArray(parsed.urls)) urls = parsed.urls.filter((value) => typeof value === "string");
        } catch {
          send(res, 400, JSON.stringify({ error: "Bad request" }), "application/json");
          return;
        }
        const result = await catalog(urls);
        send(res, 200, JSON.stringify(result), "application/json; charset=utf-8");
        return;
      }
      send(res, 404, "Not found", "text/plain; charset=utf-8");
    } catch {
      send(res, 500, JSON.stringify({ error: "Check failed." }), "application/json");
    }
  });

  server.on("error", (error) => {
    if (error && error.code === "EADDRINUSE" && port < 8796) {
      listen(port + 1);
      return;
    }
    console.error("Latch could not start.", error.message || error);
    process.exit(1);
  });

  server.listen(port, "127.0.0.1", () => {
    const url = `http://127.0.0.1:${port}`;
    console.log("");
    console.log("  Latch is running on this computer.");
    console.log("  Leave this window open. Closing it stops the alarm.");
    console.log(`  ${url}`);
    console.log("");
    openBrowser(url);
  });
}

listen(8787);
